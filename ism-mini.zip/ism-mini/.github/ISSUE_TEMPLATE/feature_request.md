---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''
---

### 🚀 Suggested Feature

<!---
Please describe the suggested feature in detail :)
It would be really nice if you could add a sudo code-blocks related to the feature
-->

### 🎉 Expected Result

<!---
Please describe the expected result.
It would be really nice if you could add a sudo code-blocks.
-->

### 🔥 Motivation

<!--- Please describe the source you got motivations from (if neccessary)-->

### 🐤 Discussions

<!---
Please put list of topics you want to discuss. (if necessary)

- [ ] any topic you want to discuss
-->
