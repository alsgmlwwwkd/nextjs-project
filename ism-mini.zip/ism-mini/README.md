# Next.js template for creact-next-app

### Usage

```bash
yarn create next-app my-app -e https://github.com/coxwave/nextjs-template
```