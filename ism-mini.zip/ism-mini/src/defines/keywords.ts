import originKeywords from '../../assets/keywords.json';

const PUBLISHERS = [
  '연합뉴스',
  '뉴스1',
  '이데일리',
  '뉴시스',
  '서울경제',
  '파이낸셜뉴스',
  'KBS',
  '해럴드경제',
  '경향신문',
];

const BLACK_LIST = [
  '기사내용',
  '었습니다',
  'ㅂ니다',
  '가운데',
  '서비스',
  '영업익',
  '지난해',
  '습니다',
  '나타나',
  '지난달',
  '전년比',
  '2021',
  '2022',
  ...PUBLISHERS,
  ...Array.from({ length: 31 }, (_, idx) => `${idx + 1}일`),
  ...Array.from({ length: 12 }, (_, idx) => `${idx + 1}월`),
  ...Array.from({ length: 4 }, (_, idx) => `${idx + 1}분기`),
];

export const keywords = originKeywords.filter((keyword) => {
  return !BLACK_LIST.includes(keyword.text);
});
