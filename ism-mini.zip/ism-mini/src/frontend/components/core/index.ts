export { default as Loading } from './DynamicLoading';
