import moment from 'moment';
import 'moment/locale/ko';

moment.locale('ko');

export function fromNow(date: string | Date) {
  return moment(date).fromNow();
}
