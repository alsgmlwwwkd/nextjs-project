import 'tippy.js/dist/tippy.css';
import 'tippy.js/animations/scale.css';

import dynamic from 'next/dynamic';
import { useRouter } from 'next/router';

import { keywords } from '@src/defines/keywords';

const ReactWordcloud = dynamic(() => import('react-wordcloud'), { ssr: false });

export default function IndexPage() {
  const router = useRouter();

  return (
    <div className="h-scrreen flex items-center justify-center overflow-hidden">
      <div className="transform scale-[1.7] translate-y-10">
        <ReactWordcloud
          words={keywords}
          maxWords={500}
          minSize={[1580, 900]}
          callbacks={{ onWordClick: (word) => router.push(`/search?keyword=${word.text}`) }}
          options={{ rotations: 0 }}
        />
      </div>
    </div>
  );
}
