import { NextApiRequest, NextApiResponse } from 'next';

import { NextApiBuilder } from '@src/backend/api-wrapper';
import { ApiError } from '@src/defines/errors';
import { connectMongo } from '@src/utils/mongodb/connect';

import type { ObjectId } from 'bson';

export type News = {
  _id: ObjectId;
  id: string;
  title: string;
  publisher: string;
  created_at: string;
  summary: string;
  href: string;
};

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method === 'POST') {
    const keyword = req.body.keyword;

    if (typeof keyword !== 'string') throw new ApiError('VALIDATION_ERROR');

    const { db } = await connectMongo();

    const news = await db
      .collection<News>('news')
      .aggregate([
        {
          $search: {
            index: 'default',
            text: {
              query: keyword,
              path: {
                wildcard: '*',
              },
            },
          },
        },
      ])
      .sort({ created_at: -1 })
      .limit(10)
      .toArray();

    return res.json(news);
  }
};

export default new NextApiBuilder(handler).build();
