import { NextApiRequest, NextApiResponse } from 'next';

import { NextApiBuilder } from '@src/backend/api-wrapper';
import { connectMongo } from '@src/utils/mongodb/connect';

// This is not in use.
// Only used for uploading crawled news data to database.
const handler = async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method === 'POST') {
    const { db } = await connectMongo();

    const result = await db.collection('news').insertMany(req.body);

    return res.status(201).json(result);
  }
};

export default new NextApiBuilder(handler).build();
