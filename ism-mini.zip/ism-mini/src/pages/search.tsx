import { Disclosure } from '@headlessui/react';
import { ChevronDownIcon } from '@heroicons/react/outline';
import cn from 'classnames';
import { NextSeo } from 'next-seo';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

import { fetcher } from '@src/frontend/lib/fetcher';
import { fromNow } from '@src/utils/moment';

import LoadingPage from './loading';

import type { News } from './api/search';

export default function SearchPage() {
  const router = useRouter();
  const [news, setNews] = useState<News[]>([]);
  const [loading, setloading] = useState<boolean>(true);

  const keyword = router.query.keyword ?? null;

  useEffect(() => {
    if (!keyword) return;

    fetcher
      .post('/api/search', { json: { keyword } })
      .json<News[]>()
      .then((data) => {
        setNews(data);
      })
      .finally(() => {
        setloading(false);
      });
  }, [keyword]);

  if (loading) return <LoadingPage />;

  return (
    <>
      <NextSeo title={`ISM - ${keyword}`} />
      <div className="max-w-screen-lg mx-auto pt-16">
        <button className="hover:underline" onClick={() => router.push('/')}>
          ← 돌아가기
        </button>
        <h2 className="text-4xl text-center">
          <span className="font-mono font-medium text-sky-500">{keyword}</span>
        </h2>
        <div className="divide-y-[1px] mt-8">
          {news.map((item) => (
            <Disclosure as="div" key={item.id}>
              {({ open }) => (
                <>
                  <div className="text-lg hover:bg-gray-50 rounded-sm px-2 h-16">
                    <Disclosure.Button className="text-left w-full items-center flex justify-between text-gray-400 h-full">
                      <div className="flex items-center space-x-8">
                        <span className="text-sm sm:text-base font-medium text-gray-900 line-clamp-1">
                          {item.title}
                        </span>
                        <span className="text-sm">{fromNow(item.created_at)}</span>
                      </div>
                      <span className="ml-2 sm:ml-6 h-7 flex items-center">
                        <ChevronDownIcon
                          className={cn(open ? '-rotate-180' : 'rotate-0', 'h-6 w-6 transform')}
                          aria-hidden="true"
                        />
                      </span>
                    </Disclosure.Button>
                  </div>
                  <Disclosure.Panel className="mt-2 py-4 px-2">
                    <div className="flex flex-col">
                      <p className="text-base text-gray-600">{item.summary}</p>
                      <a
                        className="text-gray-500 hover:underline hover:opacity-70 self-end"
                        href={item.href}
                        target="_blank"
                        rel="noreferrer noopener"
                      >
                        자세히 보기
                      </a>
                    </div>
                  </Disclosure.Panel>
                </>
              )}
            </Disclosure>
          ))}
        </div>
      </div>
    </>
  );
}
