import { Loading } from '@src/frontend/components/core';

export default function LoadingPage() {
  return <Loading />;
}
